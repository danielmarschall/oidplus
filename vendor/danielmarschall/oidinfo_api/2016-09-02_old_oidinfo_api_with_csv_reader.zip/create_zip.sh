#!/bin/bash

DIR=$( dirname "$0" )

cd "$DIR"

if [ -f oidinfo_api.zip ]; then
	rm oidinfo_api.zip
fi

zip oidinfo_api.zip *

